echo Building SimplePut
dotnet build SimplePut.csproj